/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemaveterinario;

import javax.swing.JOptionPane;

public class Usuarios {
    private int[] id;
    private String[] nombre;
    private String[] rol;
    private int contador;

    private static final String[] ROLES_DISPONIBLES = {"Administrador", "Encargado", "Invitado"};

    public Usuarios() {
        id = new int[0];
        nombre = new String[0];
        rol = new String[0];
        contador = 0;
    }

    public void definirYRegistrarUsuarios() {
        int cantidad = 0;

        while (cantidad <= 0) {
            try {
                String input = JOptionPane.showInputDialog("¿Cuántos usuarios desea registrar?");
                if (input == null) return; // Cancelar o cerrar -> salir

                cantidad = Integer.parseInt(input);
                if (cantidad <= 0) {
                    JOptionPane.showMessageDialog(null, "Ingrese un número mayor a 0.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Ingrese un número válido.");
            }
        }

        id = new int[cantidad];
        nombre = new String[cantidad];
        rol = new String[cantidad];
        contador = 0;

        while (contador < cantidad) {
            String nombreInput = JOptionPane.showInputDialog("Ingrese el nombre del usuario " + (contador + 1) + ":");
            if (nombreInput == null) return; // Cancelar o cerrar -> salir

            if (nombreInput.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "El nombre no puede estar vacío.");
                continue;
            }

            String rolInput = (String) JOptionPane.showInputDialog(
                    null,
                    "Seleccione el rol del usuario " + (contador + 1) + ":",
                    "Rol",
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    ROLES_DISPONIBLES,
                    ROLES_DISPONIBLES[0]);

            if (rolInput == null) {
                JOptionPane.showMessageDialog(null, "Debe seleccionar un rol.");
                continue;
            }

            id[contador] = 3000 + contador;
            nombre[contador] = nombreInput.trim();
            rol[contador] = rolInput;
            contador++;
        }

        JOptionPane.showMessageDialog(null, cantidad + " usuarios registrados correctamente.");
    }

    public void mostrarUsuarios() {
        if (contador == 0) {
            JOptionPane.showMessageDialog(null, "No hay usuarios registrados.");
            return;
        }

        StringBuilder lista = new StringBuilder("Usuarios registrados:\n");
        for (int i = 0; i < contador; i++) {
            lista.append("ID: ").append(id[i])
                 .append(", Nombre: ").append(nombre[i])
                 .append(", Rol: ").append(rol[i]).append("\n");
        }
        JOptionPane.showMessageDialog(null, lista.toString());
    }

    public static void menuUsuarios(Usuarios usuarios) {
        boolean continuar = true;
        String[] opciones = {
            "1. Registrar usuarios",
            "2. Mostrar usuarios",
            "3. Volver al menú principal"
        };

        while (continuar) {
            String opcionStr = (String) JOptionPane.showInputDialog(
                    null,
                    "Gestión de Usuarios\nSeleccione una opción:",
                    "Usuarios",
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    opciones,
                    opciones[0]);

            if (opcionStr == null) return; // Cancelar o cerrar -> salir menú

            switch (opcionStr.charAt(0)) {
                case '1' -> usuarios.definirYRegistrarUsuarios();
                case '2' -> usuarios.mostrarUsuarios();
                case '3' -> continuar = false;
                default -> JOptionPane.showMessageDialog(null, "Opción inválida. Intente nuevamente.");
            }
        }
    }
}
