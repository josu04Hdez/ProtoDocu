/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemaveterinario;

import javax.swing.JOptionPane;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Inventarios {
    
    private final String[] productos = new String[100];
    private final int[] cantidades = new int[100];
    private int contador = 0;

    public void menuInventarios() {
        boolean continuar = true;

        while (continuar) {
            try {
                String[] opciones = {
                    "1. Agregar producto",
                    "2. Consultar producto",
                    "3. Modificar producto",
                    "4. Eliminar producto",
                    "5. Ver todos los productos",
                    "6. Salir al menú principal"
                };

                String seleccion = (String) JOptionPane.showInputDialog(
                        null,
                        "Gestión de Inventario\nSeleccione una opción:",
                        "Menú de Inventario",
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        opciones,
                        opciones[0]);

                if (seleccion == null || seleccion.startsWith("6")) {
                    continuar = false;
                    continue;
                }

                switch (seleccion.charAt(0)) {
                    case '1' -> agregarProducto();
                    case '2' -> consultarProducto();
                    case '3' -> modificarProducto();
                    case '4' -> eliminarProducto();
                    case '5' -> mostrarProductos();
                    default -> JOptionPane.showMessageDialog(null, "Opción no válida.");
                }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error inesperado: " + e.getMessage());
            }
        }
    }

    private void agregarProducto() {
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del producto:");
        if (nombre == null || nombre.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Nombre no válido.");
            return;
        }

        String cantidadStr = JOptionPane.showInputDialog("Ingrese la cantidad:");
        try {
            int cantidad = Integer.parseInt(cantidadStr);
            productos[contador] = nombre;
            cantidades[contador] = cantidad;
            contador++;
            JOptionPane.showMessageDialog(null, "Producto agregado correctamente.");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Cantidad inválida.");
        }
    }

    private void consultarProducto() {
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del producto a consultar:");
        if (nombre == null || nombre.isEmpty()) return;

        for (int i = 0; i < contador; i++) {
            if (productos[i].equalsIgnoreCase(nombre)) {
                JOptionPane.showMessageDialog(null, "Producto: " + productos[i] + "\nCantidad: " + cantidades[i]);
                return;
            }
        }

        JOptionPane.showMessageDialog(null, "Producto no encontrado.");
    }

    private void modificarProducto() {
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del producto a modificar:");
        if (nombre == null || nombre.isEmpty()) return;

        for (int i = 0; i < contador; i++) {
            if (productos[i].equalsIgnoreCase(nombre)) {
                String nuevaCantidadStr = JOptionPane.showInputDialog("Ingrese la nueva cantidad:");
                try {
                    int nuevaCantidad = Integer.parseInt(nuevaCantidadStr);
                    cantidades[i] = nuevaCantidad;
                    JOptionPane.showMessageDialog(null, "Cantidad modificada correctamente.");
                    return;
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Cantidad inválida.");
                    return;
                }
            }
        }

        JOptionPane.showMessageDialog(null, "Producto no encontrado.");
    }

    private void eliminarProducto() {
        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del producto a eliminar:");
        if (nombre == null || nombre.isEmpty()) return;

        for (int i = 0; i < contador; i++) {
            if (productos[i].equalsIgnoreCase(nombre)) {
                for (int j = i; j < contador - 1; j++) {
                    productos[j] = productos[j + 1];
                    cantidades[j] = cantidades[j + 1];
                }
                productos[contador - 1] = null;
                cantidades[contador - 1] = 0;
                contador--;
                JOptionPane.showMessageDialog(null, "Producto eliminado correctamente.");
                return;
            }
        }

        JOptionPane.showMessageDialog(null, "Producto no encontrado.");
    }

    private void mostrarProductos() {
        if (contador == 0) {
            JOptionPane.showMessageDialog(null, "No hay productos en el inventario.");
            return;
        }

        StringBuilder lista = new StringBuilder("Listado de productos:\n");
        for (int i = 0; i < contador; i++) {
            lista.append(i + 1).append(". ").append(productos[i])
                 .append(" - Cantidad: ").append(cantidades[i]).append("\n");
        }

        JOptionPane.showMessageDialog(null, lista.toString());
    }
}