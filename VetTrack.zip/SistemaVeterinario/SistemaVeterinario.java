/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistemaveterinario;

import javax.swing.JOptionPane;

public class SistemaVeterinario {

    public static void main(String[] args) {
      boolean sistemaActivo = false;

        // Inicio de sesión
        while (!sistemaActivo) {
            try {
                String entrada = JOptionPane.showInputDialog(
                        "¡Bienvenido!\n¿Desea ingresar al sistema?\n1. Sí\n0. No");

                if (entrada == null) {
                    JOptionPane.showMessageDialog(null, "Saliendo del sistema.");
                    return;
                }

                int ingresoSistema = Integer.parseInt(entrada);
                if (ingresoSistema == 1) {
                    sistemaActivo = true;
                } else if (ingresoSistema == 0) {
                    JOptionPane.showMessageDialog(null, "Saliendo del sistema.");
                    return;
                } else {
                    JOptionPane.showMessageDialog(null, "Ingrese una opción válida (1 o 0).");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error: Ingrese un número válido.");
            }
        }

        // Instancias
        Usuarios usuarios = new Usuarios();
        Inventarios inventarios = new Inventarios();
        boolean continuar = true;

        // Menú principal
        while (continuar) {
            try {
                String[] opciones = {
                    "1. Gestión de Usuarios",
                    "2. Inventario",
                    "3. Citas (en construcción)",
                    "4. Historial Médico (en construcción)",
                    "5. Farmacia (en construcción)",
                    "6. Salir"
                };

                String seleccion = (String) JOptionPane.showInputDialog(
                        null,
                        "VetTrack - Sistema Veterinario\nSeleccione una opción:",
                        "Menú Principal",
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        opciones,
                        opciones[0]);

                if (seleccion == null) {
                    JOptionPane.showMessageDialog(null, "Saliendo del sistema.");
                    return;
                }

                switch (seleccion.charAt(0)) {
                    case '1' -> Usuarios.menuUsuarios(usuarios);
                    case '2' -> inventarios.menuInventarios();
                    case '3' -> JOptionPane.showMessageDialog(null, "Funcionalidad de Citas en construcción.");
                    case '4' -> JOptionPane.showMessageDialog(null, "Funcionalidad de Historial Médico en construcción.");
                    case '5' -> JOptionPane.showMessageDialog(null, "Funcionalidad de Farmacia en construcción.");
                    case '6' -> {
                        JOptionPane.showMessageDialog(null, "Gracias por usar VetTrack. ¡Hasta luego!");
                        continuar = false;
                    }
                    default -> JOptionPane.showMessageDialog(null, "Opción inválida. Intente nuevamente.");
                }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error inesperado: " + e.getMessage());
            }
        }
    }
}